// ============================================================
// MyVoice — Background Service Worker v2.0
// Routes analyze + rewrite requests through your Render backend
// ============================================================

// ---- UPDATE THIS after deploying to Render ----
const SERVER_URL = "https://YOUR-APP.onrender.com";

chrome.commands.onCommand.addListener((command) => {
  if (command === "apply-my-voice") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { action: "applyVoiceShortcut" });
    });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.action === "ping") {
    sendResponse({ alive: true });
    return true;
  }

  // ---- Analyze writing samples -> get Style Blueprint ----
  if (message.action === "analyzeSamples") {
    fetch(`${SERVER_URL}/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ samples: message.samples })
    })
      .then((r) => r.json())
      .then((data) => sendResponse({ blueprint: data.blueprint, error: null }))
      .catch((err) => sendResponse({ blueprint: null, error: err.message }));
    return true;
  }

  // ---- Rewrite text using saved Style Blueprint ----
  if (message.action === "rewriteText") {
    fetch(`${SERVER_URL}/rewrite`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: message.text, blueprint: message.blueprint })
    })
      .then((r) => r.json())
      .then((data) => sendResponse({ rewritten: data.rewritten, error: null }))
      .catch((err) => sendResponse({ rewritten: null, error: err.message }));
    return true;
  }

  return true;
});
