// ============================================================
// MyVoice for ChatGPT — Content Script v1.1
// New: live streaming side-by-side rewrite panel (PRO)
//      one-click Custom Instructions injector (PRO)
// ============================================================

(function () {
  "use strict";

  // ---- STATE ----
  let activeProfile = null;
  let settings = null;
  let isEnabled = true;
  let captureBtn = null;
  let toastTimer = null;
  let btnWrapper = null;
  let autoIndicator = null;
  let observerActive = false;

  // ---- STREAMING PANEL STATE ----
  let rewriteDebounceTimer = null;
  let currentRequestId = null;
  let lastRewriteSource = "";
  let streamingObserver = null;
  let lastKnownResponseEl = null;

  // ---- INIT ----
  async function init() {
    settings = await MVStorage.getSettings();
    isEnabled = settings.enabled !== false;

    if (settings.activeProfileId) {
      const profiles = await MVStorage.getProfiles();
      activeProfile = profiles.find((p) => p.id === settings.activeProfileId) || null;
    }

    injectToast();
    tryInjectButton();
    startObserver();
    listenForMessages();
  }

  // ============================================================
  // BUTTON INJECTION
  // ============================================================

  function tryInjectButton() {
    const selectors = [
      '[data-testid="send-button"]',
      'button[aria-label="Send prompt"]',
      'button[aria-label="Send message"]',
      '#prompt-textarea',
      'form textarea',
    ];

    let anchor = null;
    for (const sel of selectors) {
      anchor = document.querySelector(sel);
      if (anchor) break;
    }

    if (!anchor || document.getElementById("mv-apply-btn")) return;

    const container = anchor.closest("div") || anchor.parentElement;
    if (!container) return;

    btnWrapper = document.createElement("div");
    btnWrapper.id = "mv-btn-wrapper";
    btnWrapper.classList.add("mv-root");

    const applyBtn = document.createElement("button");
    applyBtn.id = "mv-apply-btn";
    applyBtn.innerHTML = `<span class="mv-icon">✦</span> Apply My Voice`;
    applyBtn.title = "Apply your writing voice to this prompt (Ctrl+Shift+V)";
    applyBtn.addEventListener("click", handleApplyVoice);

    autoIndicator = document.createElement("span");
    autoIndicator.id = "mv-auto-indicator";
    autoIndicator.textContent = "Auto ON";
    autoIndicator.classList.add("mv-root");
    if (settings && settings.autoApply) autoIndicator.classList.add("visible");

    btnWrapper.appendChild(applyBtn);
    btnWrapper.appendChild(autoIndicator);

    const sendBtn = document.querySelector('[data-testid="send-button"]') ||
                    document.querySelector('button[aria-label="Send prompt"]');
    if (sendBtn && sendBtn.parentElement) {
      sendBtn.parentElement.insertBefore(btnWrapper, sendBtn);
    } else {
      container.appendChild(btnWrapper);
    }
  }

  // ============================================================
  // APPLY VOICE — inject style prompt into textarea (FREE)
  // ============================================================

  async function handleApplyVoice() {
    if (!isEnabled) { showToast("MyVoice is disabled", "error"); return; }
    if (!activeProfile) { showToast("No style profile — open popup first", "error"); return; }

    const textarea = getTextarea();
    if (!textarea) { showToast("Could not find input box", "error"); return; }

    const userText = textarea.value || textarea.textContent || "";
    const stylePrompt = MVAnalyzer.buildStylePrompt(activeProfile);
    setTextareaValue(textarea, stylePrompt + (userText || "Please write a response."));
    showToast("✦ Voice applied!", "success");

    const applyBtn = document.getElementById("mv-apply-btn");
    if (applyBtn) {
      applyBtn.classList.add("mv-active");
      setTimeout(() => applyBtn.classList.remove("mv-active"), 1500);
    }
  }

  // ============================================================
  // STREAMING SIDE-BY-SIDE PANEL (PRO)
  // Watches ChatGPT stream, rewrites in real time via Claude API
  // ============================================================

  // ============================================================
  // SIDE-BY-SIDE PANEL — local rules-based voice transformer
  // Zero API, zero backend, zero cost, works instantly.
  // Uses the style profile to transform the text directly.
  // ============================================================

  function startStreamingPanel(responseEl) {
    removeStreamingPanel();

    const originalText = responseEl.innerText || responseEl.textContent || "";
    if (!originalText.trim()) return;

    const panel = document.createElement("div");
    panel.id = "mv-streaming-panel";
    panel.classList.add("mv-root");

    panel.innerHTML = `
      <div class="mv-panel-header">
        <div class="mv-panel-title">
          <span class="mv-icon">✦</span> In Your Voice
        </div>
        <div class="mv-panel-header-actions">
          <button class="mv-panel-action-btn" id="mv-copy-voice-btn">⎘ Copy</button>
          <button class="mv-panel-action-btn mv-primary" id="mv-replace-btn">↓ Use This</button>
          <button class="mv-panel-close" id="mv-panel-close-btn">✕</button>
        </div>
      </div>
      <div class="mv-panel-cols">
        <div class="mv-panel-col">
          <div class="mv-col-label">ChatGPT's Response</div>
          <div class="mv-col-text" id="mv-col-original"></div>
        </div>
        <div class="mv-panel-col">
          <div class="mv-col-label">
            In Your Voice
            <span class="mv-rewriting-dot active" id="mv-rewriting-dot"></span>
          </div>
          <div class="mv-col-text mv-voice" id="mv-col-voice">
            <span class="mv-waiting-msg">Transforming...</span>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(panel);

    document.getElementById("mv-col-original").textContent = originalText;

    document.getElementById("mv-panel-close-btn").addEventListener("click", () => {
      removeStreamingPanel();
      stopStreamingObserver();
    });

    document.getElementById("mv-copy-voice-btn").addEventListener("click", () => {
      const el = document.getElementById("mv-col-voice");
      if (el) navigator.clipboard.writeText(el.innerText || "").then(() => showToast("Copied!", "success"));
    });

    document.getElementById("mv-replace-btn").addEventListener("click", () => {
      const el = document.getElementById("mv-col-voice");
      const textarea = getTextarea();
      if (el && textarea) {
        setTextareaValue(textarea, el.innerText || "");
        showToast("Pasted into input — send when ready!", "success");
        removeStreamingPanel();
      }
    });

    // Run the local transformation — simulate streaming word by word
    runLocalTransform(originalText);
  }

  async function runLocalTransform(originalText) {
    if (!activeProfile) return;

    const voiceCol = document.getElementById("mv-col-voice");
    const dot = document.getElementById("mv-rewriting-dot");
    if (!voiceCol) return;

    // If profile has an AI blueprint, use the backend for a proper rewrite
    if (activeProfile.blueprint) {
      voiceCol.innerHTML = '<span class="mv-waiting-msg">Rewriting in your voice...</span>';

      try {
        const response = await chrome.runtime.sendMessage({
          action: "rewriteText",
          text: originalText,
          blueprint: activeProfile.blueprint
        });

        if (response.error || !response.rewritten) {
          // Fall back to local transform if backend fails
          runLocalFallback(originalText, voiceCol, dot);
          return;
        }

        // Stream the result in with a typing effect
        voiceCol.textContent = "";
        streamTextIn(response.rewritten, voiceCol, dot);

      } catch (err) {
        runLocalFallback(originalText, voiceCol, dot);
      }

    } else {
      // No blueprint — use local rules-based transform
      runLocalFallback(originalText, voiceCol, dot);
    }
  }

  // Rules-based fallback when server is unavailable
  function runLocalFallback(originalText, voiceCol, dot) {
    const transformed = MVAnalyzer.transformText(originalText, activeProfile);
    voiceCol.textContent = "";
    streamTextIn(transformed, voiceCol, dot);
  }

  // Typing animation — streams text word by word so it feels live
  function streamTextIn(text, voiceCol, dot) {
    const words = text.split(" ");
    let i = 0;
    const interval = setInterval(() => {
      if (i >= words.length) {
        clearInterval(interval);
        if (dot) dot.classList.remove("active");
        return;
      }
      const chunk = words.slice(i, i + 4).join(" ");
      voiceCol.textContent += (i === 0 ? "" : " ") + chunk;
      i += 4;
    }, 35);
  }

  function stopStreamingObserver() {
    if (streamingObserver) { streamingObserver.disconnect(); streamingObserver = null; }
    currentRequestId = null;
    clearTimeout(rewriteDebounceTimer);
    lastRewriteSource = "";
  }

  function removeStreamingPanel() {
    const el = document.getElementById("mv-streaming-panel");
    if (el) el.remove();
  }

  // ============================================================
  // CUSTOM INSTRUCTIONS INJECTOR (PRO)
  // Fills ChatGPT's Custom Instructions field with compact
  // style profile — one-time setup, no prompt injection needed
  // ============================================================

  async function injectCustomInstructions() {
    if (!activeProfile) {
      showToast("No active profile — generate one first", "error");
      return;
    }

    const compact = MVAnalyzer.buildCompactStylePrompt(activeProfile);

    // Try to open the settings menu
    const menuSelectors = [
      '[data-testid="profile-button"]',
      'button[aria-label="Open profile menu"]',
      'nav a[href*="settings"]',
    ];

    let opened = false;
    for (const sel of menuSelectors) {
      const btn = document.querySelector(sel);
      if (btn) { btn.click(); opened = true; break; }
    }

    if (opened) {
      // Wait for menu, then find Custom Instructions option
      setTimeout(() => {
        const items = document.querySelectorAll('[role="menuitem"]');
        items.forEach((item) => {
          if (item.textContent.toLowerCase().includes("custom")) item.click();
        });
        // Then fill the textarea that appears
        setTimeout(() => tryFillCustomInstructions(compact), 700);
      }, 450);
    } else {
      // Fallback: copy to clipboard with instructions
      navigator.clipboard.writeText(compact).then(() => {
        showToast("Copied! Go to Settings → Personalization → Custom Instructions and paste", "success");
      });
    }
  }

  function tryFillCustomInstructions(text) {
    // Custom Instructions modal has two textareas:
    // [0] = "What would you like ChatGPT to know about you?"
    // [1] = "How would you like ChatGPT to respond?" ← we want this one
    const textareas = document.querySelectorAll('textarea');
    const target = textareas.length >= 2 ? textareas[1] : textareas[0];

    if (target) {
      setTextareaValue(target, text);
      target.focus();
      showToast("✦ Style saved to Custom Instructions!", "success");
    } else {
      // Modal didn't open — clipboard fallback
      navigator.clipboard.writeText(text).then(() => {
        showToast("Copied! Paste into: Settings → Personalization → Custom Instructions → How to respond", "success");
      });
    }
  }

  // ============================================================
  // CAPTURE BUTTON — on text selection
  // ============================================================

  document.addEventListener("mouseup", () => {
    setTimeout(() => {
      const selection = window.getSelection();
      const selectedText = selection ? selection.toString().trim() : "";
      removeCaptureBtn();
      if (selectedText.length < 40) return;

      captureBtn = document.createElement("button");
      captureBtn.id = "mv-capture-btn";
      captureBtn.classList.add("mv-root");
      captureBtn.textContent = "✦ Capture as My Style";

      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      captureBtn.style.top = `${rect.top + window.scrollY - 38}px`;
      captureBtn.style.left = `${rect.left + window.scrollX}px`;
      captureBtn.addEventListener("click", () => captureSelectedText(selectedText));
      document.body.appendChild(captureBtn);
    }, 10);
  });

  document.addEventListener("mousedown", (e) => {
    if (captureBtn && !captureBtn.contains(e.target)) removeCaptureBtn();
  });

  function removeCaptureBtn() {
    const el = document.getElementById("mv-capture-btn");
    if (el) el.remove();
    captureBtn = null;
  }

  async function captureSelectedText(text) {
    removeCaptureBtn();
    const samples = await MVStorage.getSamples();
    if (samples.length >= 10) showToast("⚠ 10+ samples — remove some first", "error");
    await MVStorage.saveSample({
      id: `sample_${Date.now()}`,
      label: "Captured from Chat",
      text,
      createdAt: new Date().toISOString()
    });
    showToast("✦ Captured as writing sample!", "success");
  }

  // ============================================================
  // MUTATION OBSERVER
  // ============================================================

  function startObserver() {
    if (observerActive) return;
    observerActive = true;

    let responseCheckDebounce = null;

    const observer = new MutationObserver(() => {
      // Re-inject button if it disappeared (ChatGPT re-renders frequently)
      if (!document.getElementById("mv-apply-btn")) tryInjectButton();

      // Auto-apply hook for keyboard send
      if (settings && settings.autoApply && activeProfile) {
        const textarea = getTextarea();
        if (textarea && !textarea.dataset.mvHooked) {
          textarea.dataset.mvHooked = "1";
          textarea.addEventListener("keydown", (e) => {
            if (e.key === "Enter" && !e.shiftKey && activeProfile) {
              const text = textarea.value || textarea.textContent || "";
              if (text && !text.includes("===WRITE IN MY EXACT PERSONAL VOICE===")) {
                setTextareaValue(textarea, MVAnalyzer.buildStylePrompt(activeProfile) + text);
              }
            }
          });
        }
      }

      // Detect when ChatGPT FINISHES streaming a response
      // We wait until streaming stops before launching the panel
      if (!settings || !activeProfile || !isEnabled) return;
      if (!settings.liveRewrite) return;

      clearTimeout(responseCheckDebounce);
      responseCheckDebounce = setTimeout(() => {
        const isStreaming = !!document.querySelector('[data-testid="stop-button"]');
        if (isStreaming) return; // still going — wait

        const responseEls = document.querySelectorAll('[data-message-author-role="assistant"]');
        if (!responseEls.length) return;
        const latest = responseEls[responseEls.length - 1];
        if (latest === lastKnownResponseEl) return;

        const text = latest.innerText || latest.textContent || "";
        if (text.length < 30) return;

        lastKnownResponseEl = latest;
        startStreamingPanel(latest);
      }, 600);
    });

    observer.observe(document.body, { childList: true, subtree: true });
  }

  // ============================================================
  // MESSAGES FROM POPUP / BACKGROUND
  // ============================================================

  function listenForMessages() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      switch (message.action) {
        case "applyVoiceShortcut":    handleApplyVoice(); break;
        case "injectCustomInstructions": injectCustomInstructions(); break;
        case "profileChanged":
          activeProfile = message.profile;
          showToast(`✦ Profile: ${message.profile?.name}`, "success");
          break;
        case "settingsChanged":
          settings = message.settings;
          isEnabled = settings.enabled !== false;
          activeProfile = message.activeProfile || activeProfile;
          if (autoIndicator) autoIndicator.classList.toggle("visible", !!settings.autoApply);
          break;
        case "toggleEnabled":
          isEnabled = message.enabled;
          const btn = document.getElementById("mv-apply-btn");
          if (btn) btn.style.opacity = isEnabled ? "1" : "0.4";
          showToast(isEnabled ? "MyVoice enabled" : "MyVoice disabled for this chat", "success");
          break;
        case "getStatus":
          sendResponse({ isEnabled, hasProfile: !!activeProfile, profileName: activeProfile?.name });
          break;
      }
      return true;
    });
  }

  // ============================================================
  // HELPERS
  // ============================================================

  function getTextarea() {
    for (const sel of ['#prompt-textarea', 'div[contenteditable="true"]', 'textarea']) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  function setTextareaValue(el, value) {
    if (el.tagName === "TEXTAREA") {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
      setter.call(el, value);
      el.dispatchEvent(new Event("input", { bubbles: true }));
    } else if (el.contentEditable === "true") {
      el.textContent = value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
    }
    el.focus();
  }

  function injectToast() {
    if (document.getElementById("mv-toast")) return;
    const t = document.createElement("div");
    t.id = "mv-toast";
    t.classList.add("mv-root");
    document.body.appendChild(t);
  }

  function showToast(message, type = "success") {
    const toast = document.getElementById("mv-toast");
    if (!toast) return;
    clearTimeout(toastTimer);
    toast.textContent = message;
    toast.className = `mv-root show ${type}`;
    toastTimer = setTimeout(() => toast.classList.remove("show"), 3000);
  }

  // ---- BOOT ----
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

})();
