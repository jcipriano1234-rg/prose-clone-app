// ============================================================
// MyVoice for ChatGPT — Popup Script
// Manages samples, profiles, settings, and communicates
// with the content script on chatgpt.com
// ============================================================

(function () {
  "use strict";

  // ---- STATE ----
  let samples = [];
  let profiles = [];
  let settings = {};
  let editingProfileId = null;

  // ---- DOM REFS ----
  const $ = (id) => document.getElementById(id);

  // ---- INIT ----
  async function init() {
    samples = await MVStorage.getSamples();
    profiles = await MVStorage.getProfiles();
    settings = await MVStorage.getSettings();

    renderAll();
    bindEvents();
    injectPopupToast();
    applySettingsToUI();
  }

  function renderAll() {
    renderSamplesList();
    renderProfilesList();
    renderProfileSelect();
    renderProfileSummary();
    updateSampleCount();
  }

  // ============================================================
  // TAB SWITCHING
  // ============================================================

  function bindEvents() {
    // Tabs
    document.querySelectorAll(".tab").forEach((tab) => {
      tab.addEventListener("click", () => {
        document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
        document.querySelectorAll(".tab-content").forEach((c) => c.classList.remove("active"));
        tab.classList.add("active");
        $(`tab-${tab.dataset.tab}`).classList.add("active");
      });
    });

    // ---- VOICE TAB ----
    $("toggle-enabled").addEventListener("change", async (e) => {
      settings.enabled = e.target.checked;
      await MVStorage.saveSettings(settings);
      sendToContent({ action: "toggleEnabled", enabled: settings.enabled });
    });

    $("toggle-auto-apply").addEventListener("change", async (e) => {
      settings.autoApply = e.target.checked;
      await MVStorage.saveSettings(settings);
      sendToContentWithSettings();
    });

    $("active-profile-select").addEventListener("change", async (e) => {
      settings.activeProfileId = e.target.value || null;
      await MVStorage.saveSettings(settings);
      const activeProfile = profiles.find((p) => p.id === settings.activeProfileId) || null;
      sendToContent({ action: "profileChanged", profile: activeProfile });
      renderProfileSummary();
      renderProfilesList(); // update active indicator
    });

    $("btn-analyze").addEventListener("click", generateProfile);

    $("btn-apply-once").addEventListener("click", () => {
      sendToContent({ action: "applyVoiceShortcut" });
      window.close();
    });

    $("btn-rewrite-response").addEventListener("click", () => {
      sendToContent({ action: "rewriteResponse" });
      window.close();
    });

    // ---- SAMPLES TAB ----
    $("btn-add-sample").addEventListener("click", addSample);

    $("file-upload").addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        $("sample-text").value = ev.target.result;
        $("sample-label").value = file.name.replace(".txt", "");
      };
      reader.readAsText(file);
      e.target.value = "";
    });

    // ---- PROFILES TAB ----
    $("btn-generate-profile").addEventListener("click", generateProfile);
    $("btn-cancel-edit").addEventListener("click", () => {
      $("edit-profile-section").style.display = "none";
      editingProfileId = null;
    });
    $("btn-save-profile-json").addEventListener("click", saveProfileJson);

    // ---- VOICE TAB PRO ----
    $("btn-unlock-pro").addEventListener("click", () => {
      showToast("Stripe billing coming soon!", "success");
    });

    $("btn-save-custom-instructions").addEventListener("click", () => {
      sendToContent({ action: "injectCustomInstructions" });
      window.close();
    });

    $("toggle-live-rewrite").addEventListener("change", async (e) => {
      settings.liveRewrite = e.target.checked;
      settings.isPremium = true;
      await MVStorage.saveSettings(settings);
      sendToContentWithSettings();
      showToast(e.target.checked ? "Live rewrite ON" : "Live rewrite OFF", "success");
    });

    // ---- SETTINGS TAB ----
    // ---- API KEY ----
    loadApiKeyStatus();

    $("btn-save-api-key").addEventListener("click", async () => {
      const key = $("api-key-input").value.trim();
      if (!key || key.length < 20) {
        showToast("Please paste your full API key", "error");
        return;
      }
      await chrome.runtime.sendMessage({ action: "saveApiKey", key });
      $("api-key-input").value = "";
      $("api-key-status").textContent = "✓ API key saved";
      $("api-key-status").style.color = "var(--success)";
      showToast("API key saved!", "success");
    });

    $("btn-export").addEventListener("click", exportData);
    $("btn-import").addEventListener("click", () => $("import-file").click());
    $("import-file").addEventListener("change", importData);
    $("btn-clear-all").addEventListener("click", clearAllData);
    $("btn-reset-analysis").addEventListener("click", resetAnalysis);
  }

  function applySettingsToUI() {
    $("toggle-enabled").checked = settings.enabled !== false;
    $("toggle-auto-apply").checked = !!settings.autoApply;

    // All features fully unlocked — Stripe wired in later
    $("pro-locked").style.display = "none";
    $("pro-unlocked").style.display = "flex";
    $("pro-unlocked").style.flexDirection = "column";
    if ($("toggle-live-rewrite")) {
      $("toggle-live-rewrite").checked = settings.liveRewrite !== false;
    }
  }

  // ============================================================
  // SAMPLES
  // ============================================================

  async function addSample() {
    const label = $("sample-label").value.trim() || "My Writing";
    const text = $("sample-text").value.trim();

    if (!text || text.length < 30) {
      showToast("Please paste at least a sentence or two", "error");
      return;
    }

    if (samples.length >= 10) {
      showToast("⚠ You have 10+ samples — remove some first", "error");
      return;
    }

    const sample = {
      id: `sample_${Date.now()}`,
      label,
      text,
      createdAt: new Date().toISOString()
    };

    samples = await MVStorage.saveSample(sample);
    $("sample-label").value = "";
    $("sample-text").value = "";

    renderSamplesList();
    updateSampleCount();
    showToast("Sample added!", "success");
  }

  function renderSamplesList() {
    const list = $("samples-list");
    if (!samples.length) {
      list.innerHTML = `<div class="empty-state">No samples yet — paste your writing above!</div>`;
      return;
    }
    list.innerHTML = samples.map((s) => `
      <div class="sample-item" data-id="${s.id}">
        <div class="item-body">
          <div class="item-label">${escHtml(s.label)}</div>
          <div class="item-preview">${escHtml(s.text.slice(0, 60))}…</div>
        </div>
        <div class="item-actions">
          <button class="item-btn danger" data-action="delete-sample" data-id="${s.id}" title="Delete">🗑</button>
        </div>
      </div>
    `).join("");

    list.querySelectorAll("[data-action='delete-sample']").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        samples = await MVStorage.deleteSample(id);
        renderSamplesList();
        updateSampleCount();
        showToast("Sample removed", "success");
      });
    });
  }

  function updateSampleCount() {
    const badge = $("sample-total-badge");
    badge.textContent = samples.length;

    const hint = $("sample-count-hint");
    if (samples.length >= 10) {
      hint.textContent = "⚠ 10 samples max";
      hint.classList.add("warn");
    } else {
      hint.textContent = `${samples.length}/10`;
      hint.classList.remove("warn");
    }
  }

  // ============================================================
  // PROFILES
  // ============================================================

  async function generateProfile() {
    if (!samples.length) {
      showToast("Add at least one writing sample first", "error");
      return;
    }

    $("analyze-loading").style.display = "flex";
    $("btn-generate-profile").disabled = true;
    $("analyze-loading").querySelector("span").textContent = "Analyzing your writing style with AI...";

    try {
      // First do local analysis for rhythm/tone/structure signals
      const localProfile = MVAnalyzer.analyze(samples);
      localProfile.summary = MVAnalyzer.buildSummary(localProfile);

      // Then get AI-powered Style Blueprint via backend
      const response = await chrome.runtime.sendMessage({
        action: "analyzeSamples",
        samples: samples
      });

      if (response.error) {
        // Fall back to local-only profile if server unreachable
        console.warn("AI analysis failed, using local:", response.error);
        localProfile.blueprint = null;
        localProfile.name = `My Style ${profiles.length + 1}`;
      } else {
        localProfile.blueprint = response.blueprint;
        localProfile.name = `My Style ${profiles.length + 1}`;
      }

      profiles = await MVStorage.saveProfile(localProfile);

      if (!settings.activeProfileId) {
        settings.activeProfileId = localProfile.id;
        await MVStorage.saveSettings(settings);
      }

      renderProfilesList();
      renderProfileSelect();
      renderProfileSummary();

      const activeProfile = profiles.find((p) => p.id === settings.activeProfileId) || null;
      sendToContent({ action: "profileChanged", profile: activeProfile });
      sendToContentWithSettings();

      const msg = localProfile.blueprint
        ? "✦ AI Style Blueprint generated!"
        : "✦ Profile generated (local only — check server)";
      showToast(msg, "success");

    } catch (err) {
      showToast("Analysis failed — try again", "error");
      console.error(err);
    } finally {
      $("analyze-loading").style.display = "none";
      $("btn-generate-profile").disabled = false;
    }
  }

  function renderProfileSelect() {
    const select = $("active-profile-select");
    const current = settings.activeProfileId;
    select.innerHTML = `<option value="">— No profile selected —</option>` +
      profiles.map((p) => `<option value="${p.id}" ${p.id === current ? "selected" : ""}>${escHtml(p.name)}</option>`).join("");

    $("no-profile-hint").style.display = profiles.length === 0 ? "block" : "none";
  }

  function renderProfilesList() {
    const list = $("profiles-list");
    if (!profiles.length) {
      list.innerHTML = `<div class="empty-state">No profiles yet — generate one from your samples!</div>`;
      return;
    }
    list.innerHTML = profiles.map((p) => {
      const isActive = p.id === settings.activeProfileId;
      return `
        <div class="profile-item ${isActive ? "active-profile" : ""}" data-id="${p.id}">
          ${isActive ? `<div class="active-dot"></div>` : ""}
          <div class="item-body">
            <div class="item-label">${escHtml(p.name)}</div>
            <div class="item-preview">${p.rhythm ? `${p.rhythm.rhythmStyle} · ${p.tone ? p.tone.formality : ""} · ${p.sampleCount} sample${p.sampleCount !== 1 ? "s" : ""}` : "Profile"}</div>
          </div>
          <div class="item-actions">
            <button class="item-btn" data-action="edit-profile" data-id="${p.id}" title="Edit">✎</button>
            <button class="item-btn danger" data-action="delete-profile" data-id="${p.id}" title="Delete">🗑</button>
          </div>
        </div>
      `;
    }).join("");

    list.querySelectorAll("[data-action='edit-profile']").forEach((btn) => {
      btn.addEventListener("click", () => openProfileEditor(btn.dataset.id));
    });

    list.querySelectorAll("[data-action='delete-profile']").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        if (id === settings.activeProfileId) {
          settings.activeProfileId = null;
          await MVStorage.saveSettings(settings);
        }
        profiles = await MVStorage.deleteProfile(id);
        renderProfilesList();
        renderProfileSelect();
        renderProfileSummary();
        showToast("Profile deleted", "success");
      });
    });
  }

  function renderProfileSummary() {
    const section = $("profile-summary-section");
    const summaryText = $("profile-summary-text");
    const statsEl = $("profile-stats");
    const activeProfile = profiles.find((p) => p.id === settings.activeProfileId);

    if (!activeProfile) {
      section.style.display = "none";
      return;
    }

    section.style.display = "flex";
    summaryText.textContent = activeProfile.summary || "No summary yet.";

    const chips = [];
    if (activeProfile.rhythm) chips.push(`${activeProfile.rhythm.rhythmStyle} rhythm`);
    if (activeProfile.tone) {
      chips.push(activeProfile.tone.formality);
      chips.push(activeProfile.tone.warmth);
      chips.push(activeProfile.tone.confidence);
    }
    if (activeProfile.sampleCount) chips.push(`${activeProfile.sampleCount} samples`);

    statsEl.innerHTML = chips.map((c) => `<span class="stat-chip">${escHtml(c)}</span>`).join("");
  }

  function openProfileEditor(id) {
    const profile = profiles.find((p) => p.id === id);
    if (!profile) return;

    editingProfileId = id;
    $("profile-json-editor").value = JSON.stringify(profile, null, 2);
    $("edit-profile-section").style.display = "flex";
    $("profile-json-editor").scrollIntoView({ behavior: "smooth" });
  }

  async function saveProfileJson() {
    try {
      const parsed = JSON.parse($("profile-json-editor").value);
      parsed.id = editingProfileId; // prevent ID change
      parsed.updatedAt = new Date().toISOString();
      profiles = await MVStorage.saveProfile(parsed);
      $("edit-profile-section").style.display = "none";
      editingProfileId = null;
      renderProfilesList();
      renderProfileSelect();
      renderProfileSummary();
      showToast("Profile saved!", "success");
    } catch (err) {
      showToast("Invalid JSON — fix and try again", "error");
    }
  }

  // ============================================================
  // SETTINGS
  // ============================================================

  async function loadApiKeyStatus() {
    const res = await chrome.runtime.sendMessage({ action: "getApiKey" });
    const statusEl = $("api-key-status");
    if (!statusEl) return;
    if (res && res.key) {
      statusEl.textContent = "✓ API key is set";
      statusEl.style.color = "var(--success)";
    } else {
      statusEl.textContent = "No API key set yet";
      statusEl.style.color = "var(--text3)";
    }
  }

  async function exportData() {
    const data = await MVStorage.exportAll();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `myvoice-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast("Data exported!", "success");
  }

  async function importData(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const data = JSON.parse(ev.target.result);
        await MVStorage.importAll(data);
        samples = await MVStorage.getSamples();
        profiles = await MVStorage.getProfiles();
        settings = await MVStorage.getSettings();
        renderAll();
        applySettingsToUI();
        showToast("Data imported successfully!", "success");
      } catch (err) {
        showToast("Import failed — invalid file", "error");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  }

  async function clearAllData() {
    if (!confirm("Delete ALL samples, profiles, and settings? This cannot be undone.")) return;
    await MVStorage.clearAll();
    samples = [];
    profiles = [];
    settings = { activeProfileId: null, autoApply: false, enabled: true };
    renderAll();
    applySettingsToUI();
    showToast("All data cleared", "success");
  }

  async function resetAnalysis() {
    profiles = [];
    await chrome.storage.local.remove("mv_profiles");
    settings.activeProfileId = null;
    await MVStorage.saveSettings(settings);
    renderProfilesList();
    renderProfileSelect();
    renderProfileSummary();
    showToast("Analysis reset — samples kept", "success");
  }

  // ============================================================
  // CONTENT SCRIPT COMMUNICATION
  // ============================================================

  function sendToContent(message) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, message).catch(() => {});
      }
    });
  }

  function sendToContentWithSettings() {
    const activeProfile = profiles.find((p) => p.id === settings.activeProfileId) || null;
    sendToContent({ action: "settingsChanged", settings, activeProfile });
  }

  // ============================================================
  // TOAST
  // ============================================================

  function injectPopupToast() {
    if ($("popup-toast")) return;
    const t = document.createElement("div");
    t.id = "popup-toast";
    document.body.appendChild(t);
  }

  let toastTimer;
  function showToast(message, type = "success") {
    const toast = $("popup-toast");
    if (!toast) return;
    clearTimeout(toastTimer);
    toast.textContent = message;
    toast.className = `show ${type}`;
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
  }

  // ============================================================
  // UTILS
  // ============================================================

  function escHtml(str) {
    return (str || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  // ---- BOOT ----
  document.addEventListener("DOMContentLoaded", init);
})();
