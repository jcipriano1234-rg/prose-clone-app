// ============================================================
// MyVoice — Style Analyzer
// Extracts deep voice fingerprint from user writing samples.
// Focus: sentence rhythm, tone, structure, punctuation habits,
// clause patterns, opener/closer tendencies, formality.
// ============================================================

const MVAnalyzer = {

  // ---- ENTRY POINT ----
  // Pass an array of sample objects [{ text, label }]
  // Returns a Style Profile JSON object

  analyze(samples) {
    const allText = samples.map((s) => s.text).join("\n\n");
    const sentences = this.splitSentences(allText);
    const words = this.tokenizeWords(allText);

    return {
      id: `profile_${Date.now()}`,
      name: "My Style",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      sampleCount: samples.length,

      // ---- Sentence rhythm ----
      rhythm: this.analyzeRhythm(sentences),

      // ---- Tone & formality ----
      tone: this.analyzeTone(sentences, words),

      // ---- Structural habits ----
      structure: this.analyzeStructure(sentences),

      // ---- Punctuation fingerprint ----
      punctuation: this.analyzePunctuation(allText, sentences),

      // ---- Opener / closer patterns ----
      openers: this.analyzeOpeners(sentences),
      closers: this.analyzeClosers(sentences),

      // ---- Characteristic phrases & connectors ----
      connectors: this.analyzeConnectors(allText),
      signaturePatterns: this.findSignaturePatterns(sentences),

      // ---- Human summary for display ----
      summary: null // filled after analysis
    };
  },

  // ---- SENTENCE SPLITTING ----
  splitSentences(text) {
    // Handles abbreviations and ellipsis reasonably well
    return text
      .replace(/([.!?…])\s+/g, "$1\n")
      .split("\n")
      .map((s) => s.trim())
      .filter((s) => s.length > 5);
  },

  // ---- WORD TOKENIZATION ----
  tokenizeWords(text) {
    return text
      .toLowerCase()
      .replace(/[^a-z0-9'\s-]/g, " ")
      .split(/\s+/)
      .filter((w) => w.length > 0);
  },

  // ---- RHYTHM ANALYSIS ----
  // Looks at sentence length distribution, not just average
  analyzeRhythm(sentences) {
    const lengths = sentences.map((s) => s.split(/\s+/).length);
    const avg = lengths.reduce((a, b) => a + b, 0) / lengths.length;
    const short = lengths.filter((l) => l <= 8).length;
    const medium = lengths.filter((l) => l > 8 && l <= 20).length;
    const long = lengths.filter((l) => l > 20).length;
    const total = lengths.length || 1;
    const variance = lengths.reduce((acc, l) => acc + Math.pow(l - avg, 2), 0) / total;

    // Rhythm style
    let rhythmStyle;
    const shortRatio = short / total;
    const longRatio = long / total;
    if (shortRatio > 0.5) rhythmStyle = "punchy";
    else if (longRatio > 0.4) rhythmStyle = "flowing";
    else if (variance > 30) rhythmStyle = "varied";
    else rhythmStyle = "balanced";

    return {
      avgSentenceLength: Math.round(avg),
      shortSentenceRatio: parseFloat((shortRatio).toFixed(2)),
      mediumSentenceRatio: parseFloat((medium / total).toFixed(2)),
      longSentenceRatio: parseFloat((longRatio).toFixed(2)),
      variance: parseFloat(variance.toFixed(1)),
      rhythmStyle,
      // Distribution for prompt injection
      distribution: { short, medium, long, total }
    };
  },

  // ---- TONE & FORMALITY ----
  analyzeTone(sentences, words) {
    const informalMarkers = [
      "gonna", "wanna", "gotta", "kinda", "sorta", "lemme", "gimme",
      "yeah", "yep", "nope", "cool", "awesome", "honestly", "literally",
      "basically", "actually", "just", "like", "really", "super", "pretty",
      "tbh", "imo", "lol", "haha", "ok", "okay", "stuff", "things", "guys"
    ];
    const formalMarkers = [
      "therefore", "furthermore", "consequently", "nevertheless", "regarding",
      "pursuant", "herein", "whereby", "aforementioned", "albeit",
      "notwithstanding", "subsequently", "accordingly"
    ];
    const enthusiasmMarkers = ["!", "amazing", "great", "love", "excited", "fantastic", "wow"];
    const hedgeMarkers = ["maybe", "perhaps", "might", "could", "possibly", "i think", "i feel", "seems"];

    const wordSet = new Set(words);
    const informalScore = informalMarkers.filter((m) => wordSet.has(m)).length;
    const formalScore = formalMarkers.filter((m) => wordSet.has(m)).length;

    const allText = sentences.join(" ").toLowerCase();
    const exclamations = (allText.match(/!/g) || []).length;
    const enthusiasmScore = enthusiasmMarkers.filter((m) => allText.includes(m)).length + exclamations;
    const hedgeScore = hedgeMarkers.filter((m) => allText.includes(m)).length;

    // Determine formality level
    let formality;
    if (formalScore > informalScore * 1.5) formality = "formal";
    else if (informalScore > formalScore * 2) formality = "casual";
    else formality = "conversational";

    // Warmth
    let warmth;
    const sentenceCount = sentences.length || 1;
    const exclamRatio = exclamations / sentenceCount;
    if (exclamRatio > 0.3 || enthusiasmScore > 5) warmth = "warm";
    else if (exclamRatio < 0.05 && enthusiasmScore < 2) warmth = "neutral";
    else warmth = "friendly";

    // Confidence vs hedging
    let confidence;
    if (hedgeScore > sentenceCount * 0.2) confidence = "hedged";
    else if (hedgeScore < 2) confidence = "direct";
    else confidence = "measured";

    // Detect questions usage
    const questionCount = sentences.filter((s) => s.trim().endsWith("?")).length;
    const questionRatio = parseFloat((questionCount / sentenceCount).toFixed(2));

    return {
      formality,
      warmth,
      confidence,
      informalScore,
      formalScore,
      hedgeScore,
      exclamationRatio: parseFloat(exclamRatio.toFixed(2)),
      questionRatio,
      usesExclamations: exclamations > 3,
      usesHedging: hedgeScore > 3
    };
  },

  // ---- STRUCTURE ANALYSIS ----
  analyzeStructure(sentences) {
    // How does the writer build sentences?
    const startsWithI = sentences.filter((s) => /^i\s/i.test(s)).length;
    const startsWithConjunction = sentences.filter((s) =>
      /^(and|but|so|because|although|even though|if|when|since)\s/i.test(s)
    ).length;
    const usesParentheses = sentences.filter((s) => /\(.*\)/.test(s)).length;
    const usesDash = sentences.filter((s) => /\s—\s|\s-\s/.test(s)).length;
    const usesColon = sentences.filter((s) => /:/.test(s)).length;
    const total = sentences.length || 1;

    // Clause complexity
    const complexSentences = sentences.filter((s) => {
      const clauseMarkers = s.match(/,\s*(which|that|who|where|when|although|because|if|since)/gi) || [];
      return clauseMarkers.length >= 2;
    }).length;

    // Lists tendency
    const listSentences = sentences.filter((s) => /:\s*\n|\band\b.*\band\b.*\band\b/i.test(s)).length;

    return {
      startsWithIRatio: parseFloat((startsWithI / total).toFixed(2)),
      startsWithConjunctionRatio: parseFloat((startsWithConjunction / total).toFixed(2)),
      usesParentheses: usesParentheses > 2,
      usesDash: usesDash > 2,
      usesColon: usesColon > 2,
      complexSentenceRatio: parseFloat((complexSentences / total).toFixed(2)),
      likelyUsesList: listSentences > 1,
      startsWithConjunction: startsWithConjunction > Math.floor(total * 0.1)
    };
  },

  // ---- PUNCTUATION FINGERPRINT ----
  analyzePunctuation(allText, sentences) {
    const total = sentences.length || 1;
    const commaPerSentence = parseFloat(
      ((allText.match(/,/g) || []).length / total).toFixed(2)
    );
    const semicolons = (allText.match(/;/g) || []).length;
    const ellipsis = (allText.match(/\.\.\.|…/g) || []).length;
    const dashes = (allText.match(/—|-{2}/g) || []).length;
    const exclamations = (allText.match(/!/g) || []).length;

    return {
      commaPerSentence,
      usesSemicolons: semicolons > 2,
      usesEllipsis: ellipsis > 2,
      usesDashes: dashes > 2,
      exclamationsPerSentence: parseFloat((exclamations / total).toFixed(2)),
      semicolonCount: semicolons,
      ellipsisCount: ellipsis
    };
  },

  // ---- OPENER PATTERNS ----
  // Captures how the writer starts sentences
  analyzeOpeners(sentences) {
    const openerPatterns = [
      { label: "I + verb", regex: /^I (am|was|have|had|think|feel|know|want|need|like|love|do|did|would|will|just|always|never|really)/i },
      { label: "Time opener", regex: /^(When|After|Before|Once|As soon as|By the time)/i },
      { label: "Contrast opener", regex: /^(But|However|Although|Even though|Despite)/i },
      { label: "Additive opener", regex: /^(And|Also|Plus|Additionally|On top of that)/i },
      { label: "Causal opener", regex: /^(So|Because|Since|Therefore|That's why|This means)/i },
      { label: "Question opener", regex: /^(What|How|Why|When|Where|Who|Is|Are|Do|Does|Can|Could|Would)/i },
      { label: "Direct statement", regex: /^(The|This|That|It|There|We|You)/i },
    ];

    const found = [];
    openerPatterns.forEach((pattern) => {
      const count = sentences.filter((s) => pattern.regex.test(s.trim())).length;
      if (count > 0) {
        found.push({ label: pattern.label, count, ratio: parseFloat((count / sentences.length).toFixed(2)) });
      }
    });

    found.sort((a, b) => b.count - a.count);
    return found.slice(0, 5);
  },

  // ---- CLOSER PATTERNS ----
  analyzeClosers(sentences) {
    const lastWords = sentences.map((s) => {
      const words = s.trim().split(/\s+/);
      return words.slice(-3).join(" ").toLowerCase().replace(/[.!?]/, "");
    });

    // Look for characteristic endings
    const checksClosers = [
      { label: "Ends with question", test: (s) => s.trim().endsWith("?") },
      { label: "Ends with action verb phrase", test: (s) => /\b(do it|go for it|try it|get it done|make it happen)\b/i.test(s) },
      { label: "Ends with certainty", test: (s) => /\b(for sure|definitely|absolutely|no doubt|100%)\b/i.test(s) },
      { label: "Ends with softener", test: (s) => /\b(i think|i hope|hopefully|maybe|perhaps)\b/i.test(s) },
    ];

    return checksClosers
      .map((c) => ({ label: c.label, count: sentences.filter(c.test).length }))
      .filter((c) => c.count > 0);
  },

  // ---- CONNECTORS ----
  // Words that link ideas — distinct voice signal
  analyzeConnectors(text) {
    const connectorList = [
      "also", "but", "so", "and", "because", "which means", "that said",
      "honestly", "basically", "actually", "in fact", "for example",
      "for instance", "like", "especially", "specifically", "overall",
      "at the end of the day", "the thing is", "the point is",
      "that being said", "on the other hand", "to be fair",
      "i mean", "you know", "right", "look", "listen"
    ];

    const lower = text.toLowerCase();
    return connectorList
      .map((c) => {
        const regex = new RegExp(`\\b${c.replace(/\s+/g, "\\s+")}\\b`, "gi");
        const count = (text.match(regex) || []).length;
        return { phrase: c, count };
      })
      .filter((c) => c.count > 0)
      .sort((a, b) => b.count - a.count)
      .slice(0, 15);
  },

  // ---- SIGNATURE PATTERNS ----
  // Multi-word phrases that are uniquely theirs
  findSignaturePatterns(sentences) {
    // Extract 2-3 word phrases and find repeating ones
    const phraseCounts = {};
    sentences.forEach((sentence) => {
      const words = sentence
        .toLowerCase()
        .replace(/[^a-z0-9'\s]/g, " ")
        .split(/\s+/)
        .filter((w) => w.length > 2);

      for (let i = 0; i < words.length - 2; i++) {
        const bigram = `${words[i]} ${words[i + 1]}`;
        const trigram = `${words[i]} ${words[i + 1]} ${words[i + 2]}`;
        phraseCounts[bigram] = (phraseCounts[bigram] || 0) + 1;
        phraseCounts[trigram] = (phraseCounts[trigram] || 0) + 1;
      }
    });

    // Filter filler bigrams
    const fillerStarts = new Set([
      "i am", "it is", "this is", "that is", "there is", "there are",
      "we are", "you are", "he is", "she is", "they are", "i have",
      "it was", "that was", "this was"
    ]);

    return Object.entries(phraseCounts)
      .filter(([phrase, count]) => count >= 2 && !fillerStarts.has(phrase))
      .sort(([, a], [, b]) => b - a)
      .slice(0, 12)
      .map(([phrase, count]) => ({ phrase, count }));
  },

  // ---- BUILD HUMAN SUMMARY ----
  buildSummary(profile) {
    const { rhythm, tone, structure, punctuation, connectors, signaturePatterns } = profile;
    const parts = [];

    // Rhythm
    if (rhythm.rhythmStyle === "punchy") parts.push("You write in short, punchy sentences");
    else if (rhythm.rhythmStyle === "flowing") parts.push("You tend to write in long, flowing sentences");
    else if (rhythm.rhythmStyle === "varied") parts.push("You mix short bursts with longer sentences naturally");
    else parts.push(`Your sentences average ${rhythm.avgSentenceLength} words with a balanced rhythm`);

    // Tone
    if (tone.formality === "casual") parts.push("your tone is casual and relaxed");
    else if (tone.formality === "formal") parts.push("you write in a formal, professional tone");
    else parts.push("your tone is conversational and approachable");

    if (tone.warmth === "warm") parts.push("with warmth and enthusiasm");
    if (tone.confidence === "hedged") parts.push("and you often hedge your statements");
    else if (tone.confidence === "direct") parts.push("and you tend to be direct and confident");

    // Structure
    if (structure.startsWithConjunction) parts.push("you often start sentences with 'And', 'But', or 'So'");
    if (structure.usesDash) parts.push("you use em-dashes for asides");
    if (punctuation.usesEllipsis) parts.push("you use ellipsis to trail off...");

    // Signature phrases
    if (signaturePatterns.length > 0) {
      const top3 = signaturePatterns.slice(0, 3).map((p) => `"${p.phrase}"`).join(", ");
      parts.push(`your signature phrases include ${top3}`);
    }

    // Top connectors
    if (connectors.length > 0) {
      const topConnectors = connectors.slice(0, 3).map((c) => `"${c.phrase}"`).join(", ");
      parts.push(`you frequently connect ideas with ${topConnectors}`);
    }

    return parts.join("; ") + ".";
  },

  // ---- COMPACT STYLE PROMPT (for Custom Instructions ~800 chars) ----
  // Distills the full profile into a tight paragraph that fits ChatGPT's
  // Custom Instructions "How would you like ChatGPT to respond?" field
  buildCompactStylePrompt(profile) {
    const { rhythm, tone, structure, punctuation, connectors, signaturePatterns } = profile;
    const lines = [];

    // Rhythm
    lines.push(`Write in a ${rhythm.rhythmStyle} rhythm with ~${rhythm.avgSentenceLength}-word sentences (${Math.round(rhythm.shortSentenceRatio*100)}% short, ${Math.round(rhythm.longSentenceRatio*100)}% long).`);

    // Tone
    lines.push(`Tone: ${tone.formality}, ${tone.warmth}, ${tone.confidence}.`);
    if (tone.usesExclamations) lines.push(`Use occasional exclamation marks.`);
    if (tone.usesHedging) lines.push(`Soften claims with "I think", "maybe", "probably".`);
    if (tone.questionRatio > 0.1) lines.push(`Ask rhetorical questions occasionally.`);

    // Structure habits
    const habits = [];
    if (structure.startsWithConjunction) habits.push(`start sentences with And/But/So`);
    if (structure.usesDash) habits.push(`use em-dashes for asides`);
    if (punctuation.usesEllipsis) habits.push(`use ellipsis to trail off`);
    if (structure.usesParentheses) habits.push(`use parentheses for asides`);
    if (habits.length) lines.push(`Habits: ${habits.join(", ")}.`);

    // Connectors
    if (connectors.length) {
      lines.push(`Favorite connectors: ${connectors.slice(0,6).map(c=>c.phrase).join(", ")}.`);
    }

    // Signature phrases
    if (signaturePatterns.length) {
      lines.push(`Signature phrases: ${signaturePatterns.slice(0,4).map(p=>`"${p.phrase}"`).join(", ")}.`);
    }

    lines.push(`Always match this person's exact natural voice — not generic AI writing.`);
    return lines.join(" ");
  },

  // ---- GENERATE PROMPT INJECTION STRING ----
  // This is what gets injected into the ChatGPT prompt
  buildStylePrompt(profile) {
    const { rhythm, tone, structure, punctuation, openers, connectors, signaturePatterns } = profile;

    const lines = [
      `===WRITE IN MY EXACT PERSONAL VOICE===`,
      ``,
      `SENTENCE RHYTHM:`,
      `- Average sentence length: ${rhythm.avgSentenceLength} words`,
      `- Rhythm style: ${rhythm.rhythmStyle} (${Math.round(rhythm.shortSentenceRatio * 100)}% short, ${Math.round(rhythm.mediumSentenceRatio * 100)}% medium, ${Math.round(rhythm.longSentenceRatio * 100)}% long sentences)`,
      rhythm.rhythmStyle === "punchy" ? "- Use many short, punchy sentences. Break up ideas." : "",
      rhythm.rhythmStyle === "varied" ? "- Vary sentence length intentionally — mix short punchy lines with longer ones." : "",
      rhythm.rhythmStyle === "flowing" ? "- Use longer, flowing sentences with multiple clauses." : "",
      ``,
      `TONE & FORMALITY:`,
      `- Formality level: ${tone.formality}`,
      `- Warmth: ${tone.warmth}`,
      `- Confidence style: ${tone.confidence}`,
      tone.usesExclamations ? `- Use occasional exclamation marks for enthusiasm` : `- Avoid exclamation marks or use very sparingly`,
      tone.questionRatio > 0.1 ? `- Occasionally use rhetorical questions (${Math.round(tone.questionRatio * 100)}% of sentences are questions)` : "",
      tone.usesHedging ? `- Soften statements with hedges like "I think", "maybe", "probably"` : "",
      ``,
      `SENTENCE STRUCTURE HABITS:`,
      structure.startsWithConjunction ? `- It's natural to start sentences with "And", "But", or "So" — do this` : "",
      structure.usesDash ? `- Use em-dashes for asides — like this` : "",
      punctuation.usesEllipsis ? `- Use ellipsis occasionally to trail off or pause...` : "",
      punctuation.usesSemicolons ? `- Use semicolons to connect related thoughts; it's natural` : "",
      `- Commas per sentence: aim for ~${punctuation.commaPerSentence}`,
      structure.usesParentheses ? `- Use parentheses for asides (like this)` : "",
      ``,
    ];

    if (openers.length > 0) {
      lines.push(`SENTENCE OPENER HABITS:`);
      openers.slice(0, 3).forEach((o) => {
        lines.push(`- ${o.label} (${Math.round(o.ratio * 100)}% of sentences)`);
      });
      lines.push(``);
    }

    if (connectors.length > 0) {
      const topConnectors = connectors.slice(0, 8).map((c) => c.phrase).join(", ");
      lines.push(`CHARACTERISTIC CONNECTORS & TRANSITIONS (use these naturally):`);
      lines.push(`- ${topConnectors}`);
      lines.push(``);
    }

    if (signaturePatterns.length > 0) {
      const phrases = signaturePatterns.slice(0, 6).map((p) => `"${p.phrase}"`).join(", ");
      lines.push(`SIGNATURE PHRASES (weave in where natural):`);
      lines.push(`- ${phrases}`);
      lines.push(``);
    }

    lines.push(`CRITICAL: Do NOT sound like generic AI. Write EXACTLY as this person writes. Match their rhythm, tone, and quirks precisely. The goal is indistinguishable from their natural writing voice.`);
    lines.push(`===END VOICE PROFILE===`);
    lines.push(``);

    return lines.filter((l) => l !== "").join("\n");
  },

  // ============================================================
  // LOCAL TEXT TRANSFORMER
  // Rewrites text to match the user voice profile with zero
  // external API. Pure rules-based transformation.
  // ============================================================

  // ============================================================
  // LOCAL TEXT TRANSFORMER v3
  // Two-step approach:
  //   Step 1 — Strip ChatGPT's generic AI style out aggressively
  //   Step 2 — Rebuild using the user's actual voice profile
  // Works for any user's writing style.
  // ============================================================

  transformText(text, profile) {
    if (!text || !profile) return text;

    // Step 1: Strip AI-isms out of the raw text
    let cleaned = this.stripAIStyle(text);

    // Step 2: Split into sentences and rebuild in user's voice
    let sentences = this.splitSentences(cleaned);
    sentences = this.rebuildRhythm(sentences, profile.rhythm);
    sentences = this.rebuildVoice(sentences, profile.tone);
    sentences = this.rebuildDiction(sentences, profile.tone);
    sentences = this.rebuildPunctuation(sentences, profile.punctuation, profile.structure);
    sentences = this.rebuildTransitions(sentences, profile.connectors, profile.tone);

    return sentences.join(" ");
  },

  // ============================================================
  // STEP 1 — STRIP AI STYLE
  // Removes the patterns that make text sound like ChatGPT
  // ============================================================

  stripAIStyle(text) {
    let result = text;

    // --- Remove classic AI opening phrases ---
    const aiOpeners = [
      /^Certainly!\s*/i,
      /^Absolutely!\s*/i,
      /^Of course!\s*/i,
      /^Great question!\s*/i,
      /^Sure!\s*/i,
      /^Sure,\s*/i,
    ];
    for (const p of aiOpeners) result = result.replace(p, "");

    // --- Strip filler/throat-clearing phrases mid-text ---
    result = result
      .replace(/It(?:'s| is) worth noting that /gi, "")
      .replace(/It(?:'s| is) important to note that /gi, "")
      .replace(/It(?:'s| is) crucial to understand that /gi, "")
      .replace(/It(?:'s| is) essential to /gi, "")
      .replace(/One thing to keep in mind is that /gi, "")
      .replace(/When it comes to /gi, "")
      .replace(/In terms of /gi, "For ")
      .replace(/From a .+? perspective,? /gi, "")
      .replace(/As (mentioned|stated|noted) (above|earlier|previously),? /gi, "")
      .replace(/At the end of the day,? /gi, "")
      .replace(/All things considered,? /gi, "")
      .replace(/With that (said|being said),? /gi, "")
      .replace(/That being said,? /gi, "But ")
      .replace(/Having said that,? /gi, "But ")
      .replace(/It goes without saying that /gi, "")
      .replace(/Needless to say,? /gi, "")
      .replace(/For what it's worth,? /gi, "")
      .replace(/At the end of the day,? /gi, "")
      .replace(/In light of (this|the above),? /gi, "So ")
      .replace(/On the other hand,? /gi, "But ")
      .replace(/In conclusion,? /gi, "Overall, ")
      .replace(/To summarize,? /gi, "Basically, ")
      .replace(/To put it simply,? /gi, "Simply, ")
      .replace(/In summary,? /gi, "Overall, ")
      .replace(/Last but not least,? /gi, "And ")
      .replace(/First and foremost,? /gi, "First, ")
      .replace(/First of all,? /gi, "First, ");

    // --- Strip passive voice patterns ---
    result = result
      .replace(/it can be (seen|noted|observed) that /gi, "")
      .replace(/it should be (noted|mentioned|emphasized) that /gi, "")
      .replace(/it (has|had) been (shown|demonstrated|proven) that /gi, "")
      .replace(/there (is|are|was|were) a need to /gi, "you need to ");

    // --- Strip redundant qualifiers ---
    result = result
      .replace(/\bvery unique\b/gi, "unique")
      .replace(/\bcompletely (unique|different|separate)\b/gi, "$1")
      .replace(/\babsolutely (essential|necessary|critical)\b/gi, "$1")
      .replace(/\bquite (simply|literally|basically)\b/gi, "$1")
      .replace(/\bactually quite\b/gi, "quite")
      .replace(/\btruly (amazing|remarkable|incredible)\b/gi, "impressive");

    return result.trim();
  },

  // ============================================================
  // STEP 2 — REBUILD IN USER VOICE
  // ============================================================

  // ---- Rhythm: reshape sentence lengths to match user pattern ----
  rebuildRhythm(sentences, rhythm) {
    if (!rhythm) return sentences;
    const result = [];

    for (const sentence of sentences) {
      const words = sentence.split(/\s+/);
      const len = words.length;

      // Punchy style (avg < 12 words): break long sentences
      if (rhythm.rhythmStyle === "punchy" && len > 18) {
        const mid = Math.floor(len / 2);
        let splitAt = -1;
        for (let i = mid - 5; i <= mid + 5; i++) {
          if (i > 2 && i < len - 2 && words[i]) {
            if (words[i].match(/^(and|but|so|because|which|while|although|however|though|where|when)$/i)) {
              splitAt = i;
              break;
            }
            if (words[i - 1] && words[i - 1].match(/,$/)) {
              splitAt = i;
              break;
            }
          }
        }
        if (splitAt > 2) {
          const first = words.slice(0, splitAt).join(" ").replace(/,$/, "") + ".";
          const second = words.slice(splitAt).join(" ");
          const secondCap = second.charAt(0).toUpperCase() + second.slice(1);
          result.push(first, secondCap);
          continue;
        }
      }

      // Flowing style (avg > 18 words): merge short sentences
      if (rhythm.rhythmStyle === "flowing" && len <= 6 && result.length > 0) {
        const prev = result[result.length - 1];
        if (!prev.endsWith("?") && !prev.endsWith("!")) {
          result[result.length - 1] = prev.replace(/[.]$/, "") + ", " +
            sentence.charAt(0).toLowerCase() + sentence.slice(1);
          continue;
        }
      }

      result.push(sentence);
    }
    return result;
  },

  // ---- Voice: apply the writer's perspective and confidence level ----
  rebuildVoice(sentences, tone) {
    if (!tone) return sentences;

    return sentences.map((s) => {
      let r = s;

      // Casual/conversational: use contractions — sounds human
      if (tone.formality !== "formal") {
        r = r
          .replace(/\bI am\b/g, "I'm")
          .replace(/\bYou are\b/g, "You're")
          .replace(/\bThey are\b/g, "They're")
          .replace(/\bWe are\b/g, "We're")
          .replace(/\bIt is\b/g, "It's")
          .replace(/\bThat is\b/g, "That's")
          .replace(/\bThere is\b/g, "There's")
          .replace(/\bDo not\b/g, "Don't")
          .replace(/\bCannot\b/g, "Can't")
          .replace(/\bWill not\b/g, "Won't")
          .replace(/\bIs not\b/g, "Isn't")
          .replace(/\bAre not\b/g, "Aren't")
          .replace(/\bWas not\b/g, "Wasn't")
          .replace(/\bHave not\b/g, "Haven't")
          .replace(/\bHas not\b/g, "Hasn't")
          .replace(/\bWould not\b/g, "Wouldn't")
          .replace(/\bCould not\b/g, "Couldn't")
          .replace(/\bShould not\b/g, "Shouldn't")
          .replace(/\bDoes not\b/g, "Doesn't")
          .replace(/\bDid not\b/g, "Didn't");
      }

      // Formal: expand contractions
      if (tone.formality === "formal") {
        r = r
          .replace(/\bI'm\b/g, "I am")
          .replace(/\bYou're\b/g, "You are")
          .replace(/\bIt's\b/g, "It is")
          .replace(/\bDon't\b/g, "Do not")
          .replace(/\bCan't\b/g, "Cannot")
          .replace(/\bWon't\b/g, "Will not")
          .replace(/\bIsn't\b/g, "Is not")
          .replace(/\bAren't\b/g, "Are not")
          .replace(/\bWouldn't\b/g, "Would not")
          .replace(/\bCouldn't\b/g, "Could not")
          .replace(/\bShouldn't\b/g, "Should not")
          .replace(/\bDoesn't\b/g, "Does not")
          .replace(/\bDidn't\b/g, "Did not");
      }

      // Direct writers: strip hedging and filler
      if (tone.confidence === "direct") {
        r = r
          .replace(/\bI think that\b/gi, "")
          .replace(/\bI believe that\b/gi, "")
          .replace(/\bIt seems (like|that)\b/gi, "")
          .replace(/\bIt appears (that)?\b/gi, "")
          .replace(/\bYou might want to consider\b/gi, "Consider")
          .replace(/\bYou may want to\b/gi, "You should")
          .replace(/\bIt could be said that\b/gi, "")
          .trim();
        if (r) r = r.charAt(0).toUpperCase() + r.slice(1);
      }

      // Hedged writers: soften strong claims
      if (tone.confidence === "hedged") {
        r = r
          .replace(/\bYou must\b/gi, "You might want to")
          .replace(/\bAlways\b/gi, "Usually")
          .replace(/\bNever\b/gi, "Rarely")
          .replace(/\bThis is the best\b/gi, "This is a solid")
          .replace(/\bThis is the only way\b/gi, "One solid way is");
      }

      return r;
    });
  },

  // ---- Diction: swap vocabulary to match user's word choice level ----
  rebuildDiction(sentences, tone) {
    if (!tone) return sentences;

    const formalToCasual = {
      "therefore": "so",
      "furthermore": "also",
      "however": "but",
      "nevertheless": "still",
      "subsequently": "then",
      "consequently": "so",
      "additionally": "also",
      "moreover": "also",
      "regarding": "about",
      "in order to": "to",
      "in addition to": "on top of",
      "due to the fact that": "because",
      "in spite of the fact that": "even though",
      "for the purpose of": "to",
      "with regard to": "about",
      "in the event that": "if",
      "at this point in time": "now",
      "at the present time": "right now",
      "in the near future": "soon",
      "on a regular basis": "regularly",
      "a number of": "several",
      "the majority of": "most",
      "utilize": "use",
      "leverage": "use",
      "implement": "use",
      "facilitate": "help",
      "demonstrate": "show",
      "indicate": "show",
      "communicate": "tell",
      "obtain": "get",
      "provide": "give",
      "require": "need",
      "purchase": "buy",
      "assist": "help",
      "commence": "start",
      "terminate": "end",
      "endeavor": "try",
      "prioritize": "focus on",
      "ensure": "make sure",
      "achieve": "reach",
      "accomplish": "do",
      "substantial": "big",
      "significant": "major",
      "numerous": "many",
      "sufficient": "enough",
      "optimal": "best",
      "primary": "main",
      "initial": "first",
      "additional": "more",
      "currently": "right now",
      "previously": "before",
    };

    const casualToFormal = {
      "gonna": "going to",
      "wanna": "want to",
      "gotta": "need to",
      "kinda": "kind of",
      "sorta": "sort of",
      "yeah": "yes",
      "nope": "no",
      "super": "very",
      "a lot of": "many",
      "tons of": "many",
      "stuff": "things",
      "get": "obtain",
      "show": "demonstrate",
      "use": "utilize",
      "help": "assist",
      "start": "commence",
      "end": "conclude",
      "buy": "purchase",
    };

    const swapMap = tone.formality === "formal" ? casualToFormal : formalToCasual;
    const entries = Object.entries(swapMap).sort((a, b) => b[0].length - a[0].length);

    return sentences.map((s) => {
      let r = s;
      for (const [from, to] of entries) {
        const escaped = from.replace(/[.*+?^${}()|[\\]]/g, "\\$&");
        const regex = new RegExp("\\b" + escaped + "\\b", "gi");
        r = r.replace(regex, (match) =>
          match[0] === match[0].toUpperCase() && match[0] !== match[0].toLowerCase()
            ? to.charAt(0).toUpperCase() + to.slice(1)
            : to
        );
      }
      return r;
    });
  },

  // ---- Punctuation: match the user's punctuation habits ----
  rebuildPunctuation(sentences, punctuation, structure) {
    if (!punctuation && !structure) return sentences;

    return sentences.map((s) => {
      let r = s;

      // Remove exclamations if user doesn't use them
      if (punctuation && punctuation.exclamationsPerSentence < 0.05) {
        r = r.replace(/!$/g, ".");
      }

      // Add ellipsis occasionally if user uses them
      if (punctuation && punctuation.usesEllipsis && r.endsWith(".") && Math.random() < 0.07) {
        r = r.slice(0, -1) + "...";
      }

      // Em-dash for asides if user uses them
      if (structure && structure.usesDash) {
        r = r.replace(/, which /g, " — ");
        r = r.replace(/, and this /g, " — and this ");
      }

      return r;
    });
  },

  // ---- Transitions: replace AI transitions with user's own connectors ----
  rebuildTransitions(sentences, connectors, tone) {
    const userConnectors = (connectors || [])
      .filter((c) => c.phrase && c.phrase.length > 2)
      .slice(0, 8)
      .map((c) => c.phrase);

    const aiTransitions = [
      "additionally", "moreover", "furthermore",
      "in addition", "as a result", "in other words",
      "this highlights", "this demonstrates",
      "this suggests", "this indicates",
      "it is clear that", "clearly",
    ];

    return sentences.map((s, i) => {
      let r = s;

      // Swap AI transitions for user's connectors
      if (userConnectors.length >= 2) {
        for (const ai of aiTransitions) {
          const escaped = ai.replace(/[.*+?^${}()|[\\]]/g, "\\$&");
          const regex = new RegExp("^" + escaped + "[,]?\\s*", "gi");
          if (regex.test(r)) {
            const pick = userConnectors.find((c) => !r.toLowerCase().includes(c));
            if (pick) {
              r = r.replace(regex, pick.charAt(0).toUpperCase() + pick.slice(1) + ", ");
              break;
            }
          }
        }
      }

      // Add conjunction starters if user does this
      if (tone && i > 0 && Math.random() < 0.1) {
        if (!r.match(/^(And|But|So|However|Also|Although|Because|Since|Well|Look|Honestly)\s/i)) {
          if (tone.formality === "casual" || tone.formality === "conversational") {
            const casual = ["And ", "But ", "So "];
            r = casual[i % casual.length] + r.charAt(0).toLowerCase() + r.slice(1);
          }
        }
      }

      return r;
    });
  }
};