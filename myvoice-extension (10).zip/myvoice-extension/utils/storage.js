// ============================================================
// MyVoice — Storage Utility
// All data lives exclusively in chrome.storage.local
// ============================================================

const MVStorage = {

  // ---------- SAMPLES ----------

  async getSamples() {
    return new Promise((resolve) => {
      chrome.storage.local.get("mv_samples", (result) => {
        resolve(result.mv_samples || []);
      });
    });
  },

  async saveSample(sample) {
    const samples = await this.getSamples();
    const existing = samples.findIndex((s) => s.id === sample.id);
    if (existing >= 0) {
      samples[existing] = sample;
    } else {
      samples.push(sample);
    }
    return new Promise((resolve) => {
      chrome.storage.local.set({ mv_samples: samples }, () => resolve(samples));
    });
  },

  async deleteSample(id) {
    const samples = await this.getSamples();
    const filtered = samples.filter((s) => s.id !== id);
    return new Promise((resolve) => {
      chrome.storage.local.set({ mv_samples: filtered }, () => resolve(filtered));
    });
  },

  // ---------- PROFILES ----------

  async getProfiles() {
    return new Promise((resolve) => {
      chrome.storage.local.get("mv_profiles", (result) => {
        resolve(result.mv_profiles || []);
      });
    });
  },

  async saveProfile(profile) {
    const profiles = await this.getProfiles();
    const existing = profiles.findIndex((p) => p.id === profile.id);
    if (existing >= 0) {
      profiles[existing] = profile;
    } else {
      profiles.push(profile);
    }
    return new Promise((resolve) => {
      chrome.storage.local.set({ mv_profiles: profiles }, () => resolve(profiles));
    });
  },

  async deleteProfile(id) {
    const profiles = await this.getProfiles();
    const filtered = profiles.filter((p) => p.id !== id);
    return new Promise((resolve) => {
      chrome.storage.local.set({ mv_profiles: filtered }, () => resolve(filtered));
    });
  },

  // ---------- SETTINGS ----------

  async getSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get("mv_settings", (result) => {
        resolve(result.mv_settings || {
          activeProfileId: null,
          autoApply: false,
          enabled: true,
          isPremium: true,
          liveRewrite: true,
          chatProfiles: {}
        });
      });
    });
  },

  async saveSettings(settings) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ mv_settings: settings }, () => resolve(settings));
    });
  },

  async updateSetting(key, value) {
    const settings = await this.getSettings();
    settings[key] = value;
    return this.saveSettings(settings);
  },

  // ---------- EXPORT / IMPORT ----------

  async exportAll() {
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (result) => {
        resolve({
          mv_samples: result.mv_samples || [],
          mv_profiles: result.mv_profiles || [],
          mv_settings: result.mv_settings || {},
          exported_at: new Date().toISOString(),
          version: "1.0.0"
        });
      });
    });
  },

  async importAll(data) {
    return new Promise((resolve, reject) => {
      if (!data.mv_samples || !data.mv_profiles) {
        reject(new Error("Invalid backup file format."));
        return;
      }
      chrome.storage.local.set({
        mv_samples: data.mv_samples,
        mv_profiles: data.mv_profiles,
        mv_settings: data.mv_settings || {}
      }, () => resolve(true));
    });
  },

  async clearAll() {
    return new Promise((resolve) => {
      chrome.storage.local.remove(["mv_samples", "mv_profiles", "mv_settings"], () => resolve());
    });
  }
};
