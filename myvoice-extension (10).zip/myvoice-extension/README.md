# MyVoice for ChatGPT

**Make ChatGPT write exactly like you.**

MyVoice analyzes your real writing samples — emails, essays, messages — and builds a deep style profile of your voice: your sentence rhythm, tone, punctuation habits, signature phrases, and structural quirks. Then it injects that profile into ChatGPT so every response sounds like *you* wrote it, not an AI.

Everything runs 100% locally. No servers. No data leaving your device.

---

## How to Install (Load Unpacked)

1. **Download or unzip** the `myvoice-extension` folder to your computer.
2. Open **Chrome** and go to `chrome://extensions/`
3. Enable **Developer Mode** (toggle in the top-right corner).
4. Click **"Load unpacked"**.
5. Select the `myvoice-extension` folder.
6. The ✦ MyVoice icon will appear in your Chrome toolbar.

---

## Basic Testing Steps

### Step 1 — Add writing samples
1. Click the ✦ icon in your toolbar to open the popup.
2. Go to the **Samples** tab.
3. Paste some of your real writing (emails, messages, etc.) into the text box.
4. Give it a label like "Work Emails" and click **Add Sample**.
5. Add 2–3 more samples for better results.

### Step 2 — Generate your Style Profile
1. Go to the **Profiles** tab.
2. Click **"⟳ Generate New Profile from All Samples"**.
3. Wait a moment — it analyzes sentence rhythm, tone, structure, and more.
4. You'll see your profile appear with stats like "punchy · casual · 3 samples".

### Step 3 — Use it on ChatGPT
1. Go to [chatgpt.com](https://chatgpt.com).
2. You'll see the **"✦ Apply My Voice"** button near the input box.
3. Type a prompt, then click the button — your style profile is prepended automatically.
4. Send the message. ChatGPT will respond in your voice.

### Step 4 — Enable Auto-Apply
- In the popup → My Voice tab, toggle **Auto-Apply Voice ON**.
- Now every prompt you send automatically gets your style injected.

### Other Features
- **Capture from chat**: Highlight any text you've written in a chat → click "✦ Capture as My Style"
- **Rewrite response**: After a response generates, click "↺ Rewrite Response" in the popup
- **Keyboard shortcut**: `Ctrl+Shift+V` (or `⌘+Shift+V` on Mac) applies your voice instantly
- **Export/Import**: Back up all your samples and profiles as JSON in the Settings tab

---

## File Structure

```
myvoice-extension/
├── manifest.json              # Manifest V3 config
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
├── background/
│   └── service-worker.js      # Keyboard shortcut handler
├── content/
│   ├── content.js             # All ChatGPT page integration
│   └── content.css            # Injected UI styles (dark/light adaptive)
├── popup/
│   ├── popup.html             # Extension popup UI
│   ├── popup.css              # Popup styles
│   └── popup.js               # All popup logic
└── utils/
    ├── storage.js             # chrome.storage.local wrapper
    └── analyzer.js            # Writing style analysis engine
```

---

## How the Style Analysis Works

MyVoice does NOT just look at your most-used nouns or common words. Instead it analyzes:

- **Sentence rhythm** — short/medium/long distribution, variance, average length
- **Tone & formality** — formal vs. casual vs. conversational markers
- **Warmth & confidence** — enthusiasm level, hedging language, directness
- **Sentence structure** — how you open sentences, whether you start with conjunctions, use of dashes/parentheses/ellipsis
- **Punctuation fingerprint** — comma density, semicolon use, ellipsis patterns, exclamation ratio
- **Opener patterns** — "I + verb", time openers, contrast/additive openers, question openers
- **Connectors & transitions** — the linking words you naturally reach for
- **Signature phrases** — 2-3 word patterns that repeat across your samples

This produces a style prompt that tells ChatGPT *exactly* how to replicate your rhythm and voice — not a vague "casual" preset, but your specific quirks.

---

## Notes & Potential Improvements

- **Better response detection**: ChatGPT's DOM structure changes frequently. If the "Apply My Voice" button stops appearing, the selectors in `content.js` may need updating.
- **Per-chat profile memory**: Could store which profile was last used per conversation ID.
- **Inline rewrite button**: Could add a per-response "rewrite in my voice" button directly under each ChatGPT response.
- **Sample quality scoring**: Could warn the user if a sample is too short or too uniform to be useful.
- **Profile naming**: Currently auto-named "My Style N" — could prompt the user to name it.
- **More analysis signals**: Could detect preferred paragraph length, list usage tendency, question frequency, etc.

---

*All data is stored locally using `chrome.storage.local`. Nothing is ever transmitted anywhere.*
