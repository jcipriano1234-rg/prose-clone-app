// ============================================================
// MyVoice — Render.com Backend Server
// Holds your Groq API key privately.
// Two endpoints:
//   POST /analyze  — forensic style analysis of writing samples
//   POST /rewrite  — rewrite text using a saved style blueprint
// ============================================================

const http = require("http");
const https = require("https");

const PORT = process.env.PORT || 3000;
const GROQ_API_KEY = process.env.GROQ_API_KEY;
const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const MODEL = "llama3-70b-8192"; // best free Groq model

// ---- CORS headers — allow requests from ChatGPT tabs ----
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};

// ---- Call Groq API ----
async function callGroq(systemPrompt, userPrompt, maxTokens = 2000) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      model: MODEL,
      max_tokens: maxTokens,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ]
    });

    const options = {
      hostname: "api.groq.com",
      path: "/openai/v1/chat/completions",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${GROQ_API_KEY}`,
        "Content-Length": Buffer.byteLength(body)
      }
    };

    const req = https.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => data += chunk);
      res.on("end", () => {
        try {
          const parsed = JSON.parse(data);
          const text = parsed?.choices?.[0]?.message?.content || "";
          resolve(text);
        } catch (e) {
          reject(new Error("Failed to parse Groq response"));
        }
      });
    });

    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

// ---- HTTP Server ----
const server = http.createServer(async (req, res) => {

  // Handle preflight
  if (req.method === "OPTIONS") {
    res.writeHead(200, CORS);
    res.end();
    return;
  }

  // Only accept POST
  if (req.method !== "POST") {
    res.writeHead(405, CORS);
    res.end(JSON.stringify({ error: "Method not allowed" }));
    return;
  }

  // Read request body
  let body = "";
  req.on("data", (chunk) => body += chunk);
  req.on("end", async () => {
    try {
      const data = JSON.parse(body);

      // ---- /analyze — forensic style analysis ----
      if (req.url === "/analyze") {
        const { samples } = data;
        if (!samples || !samples.length) {
          res.writeHead(400, CORS);
          res.end(JSON.stringify({ error: "No samples provided" }));
          return;
        }

        // Format samples for the prompt
        const samplesText = samples.map((s, i) =>
          `Sample ${i + 1} (${s.label || "Untitled"}):\n${s.text}`
        ).join("\n\n---\n\n");

        const systemPrompt = `You are the world's best forensic writing-style analyst. Your job is to reverse-engineer someone's exact personal writing style from their samples. Be brutally specific and technical. Output ONLY the Style Blueprint in the exact format requested — nothing else, no preamble, no explanation.`;

        const userPrompt = `Here are my writing samples:\n\n${samplesText}\n\nAnalyze these samples and output ONLY this exact format:\n\n**MY STYLE BLUEPRINT**\n- Always:\n- Never:\n- Vocabulary rules:\n- Sentence rules:\n- Flow & structure rules:\n- Punctuation & formatting rules:\n- Tone & personality rules:\n- Unique quirks to copy exactly:\n\nMake every bullet point brutally specific and actionable. Quote real phrases from my samples as evidence. Make it so specific that an AI can read it once and perfectly imitate me with zero leakage of its own style.`;

        const blueprint = await callGroq(systemPrompt, userPrompt, 2000);

        res.writeHead(200, CORS);
        res.end(JSON.stringify({ blueprint }));
        return;
      }

      // ---- /rewrite — rewrite text using style blueprint ----
      if (req.url === "/rewrite") {
        const { text, blueprint } = data;
        if (!text || !blueprint) {
          res.writeHead(400, CORS);
          res.end(JSON.stringify({ error: "Missing text or blueprint" }));
          return;
        }

        const systemPrompt = `You are a writing style imitator. You will be given a Style Blueprint describing someone's exact writing style, and a piece of text to rewrite. Rewrite the text to perfectly match the style blueprint. Keep ALL the same information and meaning — only change how it sounds. Output ONLY the rewritten text, nothing else. No explanations, no preamble, no "Here is the rewritten version:" — just the rewritten text directly.`;

        const userPrompt = `STYLE BLUEPRINT:\n${blueprint}\n\n---\n\nTEXT TO REWRITE:\n${text}\n\n---\n\nRewrite the text above using the style blueprint. Output only the rewritten text.`;

        const rewritten = await callGroq(systemPrompt, userPrompt, 1500);

        res.writeHead(200, CORS);
        res.end(JSON.stringify({ rewritten }));
        return;
      }

      // ---- health check ----
      if (req.url === "/health") {
        res.writeHead(200, CORS);
        res.end(JSON.stringify({ status: "ok" }));
        return;
      }

      res.writeHead(404, CORS);
      res.end(JSON.stringify({ error: "Not found" }));

    } catch (err) {
      res.writeHead(500, CORS);
      res.end(JSON.stringify({ error: err.message }));
    }
  });
});

server.listen(PORT, () => {
  console.log(`MyVoice server running on port ${PORT}`);
  if (!GROQ_API_KEY) console.warn("WARNING: GROQ_API_KEY not set!");
});
